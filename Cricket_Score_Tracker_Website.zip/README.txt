CRICKET SCORE TRACKER WEBSITE

Files:
- index.html: complete website (HTML, CSS and JavaScript in one file)

Run locally:
1. Extract this ZIP file.
2. Open index.html in Chrome, Edge, Firefox or another browser.
3. Use the scoring buttons to record runs, extras and wickets.

Publish online:
You can upload index.html to a static hosting provider such as GitHub Pages.
A public website URL is created by the hosting provider after you publish it.
This ZIP does not itself create a public internet URL.

Student project: Charla Pawan Reddy
Course: B.Tech CSE (AI & DS)
University: Marwadi University

Note: This is an educational prototype and does not implement every official
cricket law or all complex dismissal/strike-crossing scenarios.
